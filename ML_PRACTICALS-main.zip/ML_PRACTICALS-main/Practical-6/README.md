## Study and Implement K-Fold cross validation and ROC
