Implement Logistic Regression in R or Python
