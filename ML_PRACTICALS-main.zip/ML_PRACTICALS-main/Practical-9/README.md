## Implement various Clustering algorithm in R and python 
