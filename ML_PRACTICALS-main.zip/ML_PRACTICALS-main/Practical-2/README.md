Implement Linear Regression in R or Python
